# ihdm-api-v2
backEndApi for IHDM portal

clone app
npm install



