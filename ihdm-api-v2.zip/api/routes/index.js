const adminRouter  = require('./Admin-route/adminRoute');
const studentRouter = require('./Student-route/studentRoute');
const serialNumberRoute = require('./SerialNumber-route/serialNumberRoute');




module.exports= {adminRouter,studentRouter,serialNumberRoute}